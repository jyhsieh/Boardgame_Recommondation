#' Aggregate MRMC analysis results over multiple streams
#'
#' When running simulation in the cluster, there is a simulation results, as a rda (Rdata) file, for each random number stream. This function pulls those rda files and takes the statistic of interest. Then forms a dataframe for each of the statistic of interest
#'
#' @param mod Pulls data from simulation model for aggregation. If previously simulated data from "BOTH", but use only "Agreement" in this command, system will only aggregate over "Agreement" model streams. Will become part of the name for the saved results. Options are "Agreement" (for Agreement simulation model), "gRoeMetz" (for g.RoeMetz simulation model) and "BOTH"
#' @param VarRC Will become part of the name for the saved results, not for aggregation calculations. Options are "LL", "LH", "HL", "HH"
#' @param nStreams Aggregates number streams of simulated data from the first stream to the $n^(th)$ stream. You must first use aggregateOverTrials OR valid.Agreement/valid.gRoeMetz (which include the aggregateOverTrials agrument) before using aggregateOverStreams in situations with >1 trials per stream. Will become part of the name for the saved results
#' @param pathToResults Will become part of the name for the saved results. Path to the saved data
#'
#' @return A list of multiple dataframes. Each dataframe represents one statistic of interest from all trials and streams. With mulitple statistis of interest, aggregateOverStreams will output a list of multiple dataframes.
#' @export
#'
#' @examples
#' mod = "BOTH"
#' VarRC = "LL"
#' nStreams = 2
#' trials = 5
#' pathToResults = tempdir()
#' fileName_Batch = "validation"
#' createBatFile(mod, VarRC, nStreams, trials, pathToResults, fileName_Batch)
#' file = paste(pathToResults,"/", fileName_Batch, sep="")
#' executeBatFile(file)
#' results = aggregateOverStreams(mod, VarRC, nStreams, pathToResults)
aggregateOverStreams = function(mod, VarRC, nStreams, pathToResults) {
  # browser()
  if (mod == "BOTH"){
    mod = c("Agreement","gRoeMetz")
  }
  agg.ROC.Agreement = NULL
  agg.AUC.Agreement = NULL
  agg.BCK.Agreement = NULL
  agg.ROC.gRoeMetz = NULL
  agg.AUC.gRoeMetz = NULL
  agg.BCK.gRoeMetz = NULL

  for (streamID in 1:nStreams) {
    for (sim.mod in mod) {
      fileName = paste("valid.",sim.mod,".",VarRC,streamID,".rda",sep="")
      load(paste(pathToResults,"/",fileName,sep=""))
      if (sim.mod == "Agreement") {
        ROC.data.frame = cbind(aggregateOverTrials.Agreement[["mc.ROCs"]],streamID=streamID)
        AUC.data.frame = cbind(aggregateOverTrials.Agreement[["mc.AUCs"]],streamID=streamID)
        BCK.data.frame = cbind(aggregateOverTrials.Agreement[["mc.BCK"]],streamID=streamID)
        # c(rep(streamID,dim(ROC.data.frame)[1]))
        agg.ROC.Agreement = rbind(agg.ROC.Agreement, ROC.data.frame)
        agg.AUC.Agreement = rbind(agg.AUC.Agreement, AUC.data.frame)
        agg.BCK.Agreement = rbind(agg.BCK.Agreement, BCK.data.frame)
      }
      if (sim.mod == "gRoeMetz") {
        ROC.data.frame = cbind(aggregateOverTrials.gRoeMetz[["mc.ROCs"]],streamID=streamID)
        AUC.data.frame = cbind(aggregateOverTrials.gRoeMetz[["mc.AUCs"]],streamID=streamID)
        BCK.data.frame = cbind(aggregateOverTrials.gRoeMetz[["mc.BCK"]],streamID=streamID)
        agg.ROC.gRoeMetz = rbind(agg.ROC.gRoeMetz, ROC.data.frame)
        agg.AUC.gRoeMetz = rbind(agg.AUC.gRoeMetz, AUC.data.frame)
        agg.BCK.gRoeMetz = rbind(agg.BCK.gRoeMetz, BCK.data.frame)
      }

    }
  }



  if (min(mod == "Agreement")==1) {
    agg.AUC.Agreement$Trials = 1:dim(agg.AUC.Agreement)[1]
    agg.BCK.Agreement$Trials = 1:dim(agg.BCK.Agreement)[1]
    agg.ROC.Agreement$sim.mod = rep("Agreement",each= nrow(agg.ROC.Agreement))
    agg.AUC.Agreement$sim.mod = rep("Agreement",each= nrow(agg.AUC.Agreement))
    agg.BCK.Agreement$sim.mod = rep("Agreement",each= nrow(agg.BCK.Agreement))
    return(list(
      agg.ROC = agg.ROC.Agreement,
      agg.AUC = agg.AUC.Agreement,
      agg.BCK = agg.BCK.Agreement
    ))
  }
  if (min(mod == "gRoeMetz")==1) {
    agg.AUC.gRoeMetz$Trials = 1:dim(agg.AUC.gRoeMetz)[1]
    agg.BCK.gRoeMetz$Trials = 1:dim(agg.BCK.gRoeMetz)[1]
    agg.ROC.gRoeMetz$sim.mod = rep("gRoeMetzt",each= nrow(agg.ROC.gRoeMetz))
    agg.AUC.gRoeMetz$sim.mod = rep("gRoeMetz",each= nrow(agg.AUC.gRoeMetz))
    agg.BCK.gRoeMetz$sim.mod = rep("gRoeMetz",each= nrow(agg.BCK.gRoeMetz))
    return(list(
      agg.ROC = agg.ROC.gRoeMetz,
      agg.AUC = agg.AUC.gRoeMetz,
      agg.BCK = agg.BCK.gRoeMetz
    ))
  } else {

    agg.ROC.Agreement$Trials = rep(1:dim(agg.AUC.Agreement)[1],
                                   each = dim(agg.ROC.Agreement)[1]/dim(agg.AUC.Agreement)[1])

    agg.AUC.Agreement$Trials = 1:dim(agg.AUC.Agreement)[1]

    agg.BCK.Agreement$Trials = 1:dim(agg.BCK.Agreement)[1]

    agg.ROC.gRoeMetz$Trials = rep(1:dim(agg.AUC.gRoeMetz)[1],
                                   each = dim(agg.ROC.gRoeMetz)[1]/dim(agg.AUC.gRoeMetz)[1])

    agg.AUC.gRoeMetz$Trials = 1:dim(agg.AUC.gRoeMetz)[1]

    agg.BCK.gRoeMetz$Trials = 1:dim(agg.BCK.gRoeMetz)[1]

    agg.ROC = rbind(agg.ROC.Agreement, agg.ROC.gRoeMetz)
    agg.ROC$sim.mod = rep(c("Agreement","gRoeMetz"),each= nrow(agg.ROC.Agreement))
    agg.ROC$Trial = paste("Trial",formatC(agg.ROC$Trials,width = 3,flag=0))

    agg.AUC = rbind(agg.AUC.Agreement, agg.AUC.gRoeMetz)
    agg.AUC$sim.mod = rep(c("Agreement","gRoeMetz"),each= nrow(agg.AUC.Agreement))
    agg.AUC$Trial = paste("Trial",formatC(agg.AUC$Trials,width = 3,flag=0))

    agg.BCK = rbind(agg.BCK.Agreement, agg.BCK.gRoeMetz)
    agg.BCK$sim.mod = rep(c("Agreement","gRoeMetz"),each= nrow(agg.BCK.Agreement))
    agg.BCK$Trial = paste("Trial",formatC(agg.BCK$Trials,width = 3,flag=0))

    return(list(
      agg.ROC = agg.ROC,
      agg.AUC = agg.AUC,
      agg.BCK = agg.BCK
    ))
  }
}
