#' Aggregate statistic of interest from a list containing multiple MRMC analysis results
#'
#' Statistic of interest may be AUC, variance of AUC, variance components. For each simulation trial, there is an output for the MRMC analysis. This function takes the statistic of interest from the output of each MRMC analysis, and aggregates them
#'
#' @param list.results A list containing multiple MRMC analysis results. Each MRMC analysis result is an output from doIMRMC function
#'
#' @return A list of data frames, one for each statistic of interest, created from aggregated data over trials within a single stream. This function is called into the valid.Agreement/valid.gRoeMetz function, which are used in running the simulation on cluster. This function is for local use
#' @export
#'
#' @examples
#' nTrialsPerStream = 5
#' createConfigTable(setting = "default")
#' configTable = read.csv(file.path(tempdir(),"configTable.csv"))
#' VarRC = "LL"
#' config = as.list(configTable[which(configTable$VarRC == VarRC),])
#' configs.Agreement = rep(list(config),nTrialsPerStream)
#' dFrame.Agreement = lapply(configs.Agreement, FUN = simAgreement)
#' dFrame.Agreement = lapply(dFrame.Agreement, FUN = createIMRMCdf, truePositiveFactor = "1")
#' Results.Agreement = lapply(dFrame.Agreement, FUN = doIMRMC)
#' aggregateOverTrials.Agreement = aggregateOverTrials(Results.Agreement)
aggregateOverTrials = function(list.results){
  FPF = c()
  TPF = c()
  Trial = c()
  Trials = c()
  sim.mod = c()

  AUC = c()
  varAUC = c()
  reject = c()
  AUCA = c()
  AUCB = c()

  mc.BCK = NULL
  for (t in 1:length(list.results)) {

    fpf = list.results[[t]]$ROC$`testB: Diagonal Average`$fpf
    tpf = list.results[[t]]$ROC$`testB: Diagonal Average`$tpf
    FPF = c(FPF,fpf)
    TPF = c(TPF,tpf)
    Trial = c(Trial,rep(paste("Trial",t), length(fpf)))
    Trials = c(Trials,rep(paste("Trial", formatC(t, width  =3, flag = 0)), length(fpf)))
    # sim.mod = c(sim.mod,rep("Agreement"), each = length(fpf))

    AUC[t] = list.results[[t]]$Ustat$AUCAminusAUCB[3]
    varAUC[t] = list.results[[t]]$Ustat$varAUCAminusAUCB[3]
    reject[t] = list.results[[t]]$Ustat$rejectBDG[3]
    AUCA[t] = list.results[[t]]$Ustat$AUCA[1]
    AUCB[t] = list.results[[t]]$Ustat$AUCA[2]

    mc.BCK = rbind(mc.BCK, list.results[[t]]$varDecomp$BCK$Ustat$comp$testA.testB["testA.testB",])
  }
  mc.ROCs = as.data.frame(cbind(FPF,TPF,Trial,Trials,sim.mod))
  mc.ROCs$FPF = as.numeric(as.character(mc.ROCs$FPF))
  mc.ROCs$TPF = as.numeric(as.character(mc.ROCs$TPF))

  mc.AUCs = cbind(AUC,varAUC,reject,AUCA,AUCB)
  mc.AUCs = as.data.frame(mc.AUCs)
  colnames(mc.AUCs) = c("AUC","varAUC","reject","AUCA","AUCB")
  mc.AUCs$Trial = 1:length(list.results)
  mc.AUCs$Trials = paste("Trial", formatC(1:length(list.results), width  =3, flag = 0))

  mc.BCK$Trial = 1:length(list.results)
  mc.BCK$Trials = paste("Trial", formatC(1:length(list.results), width  =3, flag = 0))

  aggregateOverTrials.doIMRMC = list(mc.ROCs = mc.ROCs,
                      mc.AUCs = mc.AUCs,
                      mc.BCK = mc.BCK)
  return(aggregateOverTrials.doIMRMC)
}





