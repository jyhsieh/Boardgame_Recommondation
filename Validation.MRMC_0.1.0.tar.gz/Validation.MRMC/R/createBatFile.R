#' Create a batch file for job submission to cluster/terminal
#'
#' A batch file is like a text file containing many lines of commands. Each command is a separate computation task.
#'
#' @param VarRC The VARiability for Reader and Case. Options: "LL", "LH", "HL", "HH"; the first character to describe reader variability, and the second character to describe case variability; for instance, "HL" denotes high reader variability and low case variabiliy
#' @param nStreams The number of random number streams that one would like to use for this simulation
#' @param mod The simulation model that one would like to use. Options: "Agreement", "gRoeMetz" and "BOTH"
#' @param pathToResults The path for the created batch file
#' @param trials The number of trials per stream; the total number of simulations would be the product of nStreams and trials
#' @param fileName_Batch The name of the created batch file
#'
#' @return A batch file
#' @export
#'
#' @examples
#' mod = "BOTH"
#' VarRC = "LL"
#' nStreams = 2
#' trials = 5
#' pathToResults = tempdir()
#' fileName_Batch = "validation"
#' createBatFile(mod, VarRC, nStreams, trials, pathToResults, fileName_Batch)
createBatFile = function(mod, VarRC, nStreams, trials, pathToResults, fileName_Batch){
  if (mod == "BOTH"){
    mod = c("Agreement","gRoeMetz")
  }

  if (.Platform$OS.type == "unix") {
    extension = ".sh"
  }
  if (.Platform$OS.type == "windows") {
    extension = ".bat"
  }

  file = paste(pathToResults,"/", fileName_Batch, extension, sep="")

  cat("#!/bin/bash", "\n", "\n", sep="",file=file,append=F)

  for (sim.mod in mod){
    for (streamID in 1:nStreams) {

      cat("Rscript -e ", shQuote(paste("Validation.MRMC::valid.", sim.mod, "(", shQuote(VarRC), ",", streamID, ",", trials, ",", shQuote(pathToResults),")",sep=""),type="cmd")
          , "\n", sep="",file=file, append=T)
    }
    cat("\n",file=file,append=T)
  }
  cat("\n",file=file,append=T)
}


