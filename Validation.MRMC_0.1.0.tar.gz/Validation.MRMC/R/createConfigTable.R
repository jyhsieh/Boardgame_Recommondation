#' Create a table of simulation configurations
#'
#' Simulation configurations includes nR (number readers), nC.neg (number negative cases), nC.pos (number positive cases), mu.neg (mean score of negative cases), mu.pos (mean score of positive cases), var_r (variability between readers), var_c (variability between cases), var_rc (variability between combinations of readers and cases)
#'
#' Alternatively, setting could also be a list of parameters (see example) that you may want to explore
#'
#' @param setting "Default" setting is from Table 1 in Roe and Metz (1997). The default setting contains sets of parameters that represent experiments of multiple structures (the structure of experiments includes the level of variation for readers and the level of variation for cases)
#'
#' @return A table of simulation configurations contains four experiments of different variability structure
#' @export
#'
#' @examples
#' createConfigTable(setting = "default")
#' createConfigTable(setting = list(nR=6, nC.neg=60, nC.pos=60, mu.neg=0, mu.pos=1, low.var_r=0.0055, high.var_r=0.03, low.var_c=0.1, high.var_c=0.3, var_rc=0.2))
createConfigTable = function(setting = "default") {
  if (setting == "default"){
    nR = 5
    nC.neg = 50
    nC.pos = 50
    mu.neg = 0
    mu.pos = 1
    low.var_r = 0.0055
    high.var_r = 0.011
    low.var_c = 0.1
    high.var_c = 0.3
    var_rc = 0.2
  } else {
    nR = setting$nR
    nC.neg = setting$nC.neg
    nC.pos = setting$nC.pos
    mu.neg = setting$mu.neg
    mu.pos = setting$mu.pos
    low.var_r = setting$low.var_r
    high.var_r = setting$high.var_r
    low.var_c = setting$low.var_c
    high.var_c = setting$high.var_c
    var_rc = setting$var_rc
  }
  LL = c("LL",nR, nC.neg, nC.pos, mu.neg, mu.pos, low.var_r, low.var_c, var_rc)
  LH = c("LH",nR, nC.neg, nC.pos, mu.neg, mu.pos, low.var_r, high.var_c, var_rc)
  HL = c("HL",nR, nC.neg, nC.pos, mu.neg, mu.pos, high.var_r, low.var_c, var_rc)
  HH = c("HH",nR, nC.neg, nC.pos, mu.neg, mu.pos, high.var_r, high.var_c, var_rc)
  configTable = rbind(LL,LH,HL,HH)
  colnames(configTable) = c("VarRC","nR","nC.neg","nC.pos","mu.neg",
                            "mu.pos","var_r","var_c","var_rc")
  configTable = as.data.frame(configTable)
  p = paste(tempdir(),"/configTable.csv",sep = "")
  # p = system.file(package="vIMRMC")
  write.csv(configTable,file = p, row.names = FALSE)
  # pS = simROC.params[which(simROC.params$Experiment == experiment),]
  # pS = lapply(pS, function(x) type.convert(as.character(x), as.is = TRUE))
  # return(pS)
}
