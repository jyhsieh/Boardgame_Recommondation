#' Execute a batch file
#'
#' @param file The batch file that you would like to execute (If in current directory, use name. If not, use the file path)
#'
#' @return Depends on the computation tasks inside the batch file. In the example, the computation tasks are to run the functions valid.Agreement and valid.gRoeMetz, and thus the outputs are rda files (Rdata), as the same as the outputs for the functions valid.Agreement and valid.gRoeMetz. In the future, the batch file may contains different computation tasks (besides the two within the current package), which may cause the function to produce a different output
#' @export
#'
#' @examples
#' mod = "BOTH"
#' VarRC = "LL"
#' nStreams = 2
#' trials = 5
#' destination = tempdir()
#' fileName_Batch = "validation"
#' createBatFile(mod, VarRC, nStreams, trials, destination, fileName_Batch)
#' file = paste(destination,"/", fileName_Batch, sep="")
#' executeBatFile(file)
executeBatFile = function(file) {
  if (.Platform$OS.type == "unix"){
    extension = ".sh"
    file = paste(file, extension, sep="")
    system(paste("chmod +x", file))
    system(file)
  }

  if (.Platform$OS.type == "windows") {
    extension = ".bat"
    file = paste(file, extension, sep="")
    shell.exec(file)
  }
}



