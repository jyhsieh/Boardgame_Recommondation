#' Simulate MRMC data with the Agreement simulation model
#'
#' @param config A list of parameters, including nR (number readers), nC.neg (number negative cases), nC.pos (number positive cases), mu.neg (mean score of negative cases), mu.pos (mean score of positive cases), var_r (variability between readers), var_c (variability between cases)
#'
#' @return A five-column MRMC dataframe. Eventually, we will convert the five-column dataframe to a four-column dataframe for iMRMC analysis. `sim.Agreement` is necessary while sim.gRoeMetz is not, because gRoeMetz simulation command is already available through the iMRMC package. To simulate gRoeMetz data, use the function `sim.gRoeMetz` in the iMRMC package. Use this command in the local method to simulate data.
#' @export
#'
#' @examples
#' createConfigTable()
#' configTable = read.csv(file.path(tempdir(),"configTable.csv"))
#' config = as.list(configTable[which(configTable$VarRC == "LL"),])
#' dFrame.Agreement = sim.Agreement(config)
sim.Agreement = function(config) {

  # Initialize ----
  nR = config$nR
  nC.neg = config$nC.neg
  nC.pos = config$nC.pos
  mu.neg = config$mu.neg
  mu.pos = config$mu.pos

  var.R = config$var_r
  var.tauR = config$var_r
  var.RE = config$var_r
  var.tauRE = config$var_r

  var.C.neg = config$var_c
  var.tauC.neg = config$var_c
  var.CE.neg = config$var_c
  var.tauCE.neg = config$var_c

  var.C.pos = config$var_c
  var.tauC.pos = config$var_c
  var.CE.pos = config$var_c
  var.tauCE.pos = config$var_c

  # mu ----
  mu.neg.mat = matrix(rep(rnorm(nC.neg,mu.neg,1),nR),nR,nC.neg,byrow =TRUE)
  mu.pos.mat = matrix(rep(rnorm(nC.pos,mu.pos,1),nR),nR,nC.pos,byrow =TRUE)

  # r X c ----
  R = rexp(nR,1/var.R)
  sd_R.neg = matrix(rep(R,nC.neg), nR, nC.neg)
  sd_R.pos = matrix(rep(R,nC.pos), nR, nC.pos)

  C.neg = rexp(nC.neg,1/var.C.neg)
  sd_C.neg = matrix(rep(C.neg,nR), nR, nC.neg, byrow= TRUE)
  sd_RC.neg = sd_C.neg + sd_R.neg
  RC.neg = apply(sd_RC.neg, c(1,2), rnorm, n= 1, mean= 0)

  C.pos = rexp(nC.pos,1/var.C.pos)
  sd_C.pos = matrix(rep(C.pos,nR), nR, nC.pos, byrow= TRUE)
  sd_RC.pos = sd_C.pos + sd_R.pos
  RC.pos = apply(sd_RC.pos, c(1,2), rnorm, n= 1, mean= 0)

  # m X r X c ----
  ## Ref Mod A
  AR = rexp(nR,1/var.tauR)
  sd_AR.neg = matrix(rep(AR,nC.neg), nR, nC.neg)
  sd_AR.pos = matrix(rep(AR,nC.pos), nR, nC.pos)

  AC.neg = rexp(nC.neg,1/var.tauC.neg)
  sd_AC.neg = matrix(rep(AC.neg,nR), nR, nC.neg, byrow= TRUE)
  sd_ARC.neg = sd_AC.neg + sd_AR.neg
  ARC.neg = apply(sd_ARC.neg, c(1,2), rnorm, n= 1, mean= 0)

  AC.pos = rexp(nC.pos,1/var.tauC.pos)
  sd_AC.pos = matrix(rep(AC.pos,nR), nR, nC.pos, byrow= TRUE)
  sd_ARC.pos = sd_AC.pos + sd_AR.pos
  ARC.pos = apply(sd_ARC.pos, c(1,2), rnorm, n= 1, mean= 0)

  ## New Mod B
  BR = rexp(nR,1/var.tauR)
  sd_BR.neg = matrix(rep(BR,nC.neg), nR, nC.neg)
  sd_BR.pos = matrix(rep(BR,nC.pos), nR, nC.pos)

  BC.neg = rexp(nC.neg,1/var.tauC.neg)
  sd_BC.neg = matrix(rep(BC.neg,nR), nR, nC.neg, byrow= TRUE)
  sd_BRC.neg = sd_BC.neg + sd_BR.neg
  BRC.neg = apply(sd_BRC.neg, c(1,2), rnorm, n= 1, mean= 0)

  BC.pos = rexp(nC.pos,1/var.tauC.pos)
  sd_BC.pos = matrix(rep(BC.pos,nR), nR, nC.pos, byrow= TRUE)
  sd_BRC.pos = sd_BC.pos + sd_BR.pos
  BRC.pos = apply(sd_BRC.pos, c(1,2), rnorm, n= 1, mean= 0)

  # r X C x E ----

  RE = rexp(nR,1/var.RE)
  sd_RE.neg = matrix(rep(RE,nC.neg), nR, nC.neg)
  sd_RE.pos = matrix(rep(RE,nC.pos), nR, nC.pos)

  CE.neg = rexp(nC.neg,1/var.C.neg)
  sd_CE.neg = matrix(rep(CE.neg,nR), nR, nC.neg, byrow= TRUE)
  sd_RCE.neg = sd_CE.neg + sd_RE.neg
  RCE.neg = apply(sd_RCE.neg, c(1,2), rnorm, n= 1, mean= 0)

  CE.pos = rexp(nC.pos,1/var.C.pos)
  sd_CE.pos = matrix(rep(CE.pos,nR), nR, nC.pos, byrow= TRUE)
  sd_RCE.pos = sd_CE.pos + sd_RE.pos
  RCE.pos = apply(sd_RCE.pos, c(1,2), rnorm, n= 1, mean= 0)

  # RCE_Y = apply(sd_RCE, c(1,2), rnorm, n= 1, mean= 0)
  # RCE_Z = apply(sd_RCE, c(1,2), rnorm, n =1, mean= 0)

  # m X r X c X e ----
  ## Ref Mod A
  ARE = rexp(nR,1/var.tauRE)
  sd_ARE.neg = matrix(rep(ARE,nC.neg), nR, nC.neg)
  sd_ARE.pos = matrix(rep(ARE,nC.pos), nR, nC.pos)

  ACE.neg = rexp(nC.neg,1/var.tauCE.neg)
  sd_ACE.neg = matrix(rep(ACE.neg,nR), nR, nC.neg, byrow= TRUE)
  sd_ARCE.neg = sd_ACE.neg + sd_ARE.neg
  ARCE.neg = apply(sd_ARCE.neg, c(1,2), rnorm, n= 1, mean= 0)

  ACE.pos = rexp(nC.pos,1/var.tauCE.pos)
  sd_ACE.pos = matrix(rep(ACE.pos,nR), nR, nC.pos, byrow= TRUE)
  sd_ARCE.pos = sd_ACE.pos + sd_ARE.pos
  ARCE.pos = apply(sd_ARCE.pos, c(1,2), rnorm, n= 1, mean= 0)

  # refCrosRCE_Y = apply(sd_refCrosRCE, c(1,2), rnorm, n= 1, mean= 0)

  ## New Mod B
  BRE = rexp(nR,1/var.tauRE)
  sd_BRE.neg = matrix(rep(BRE,nC.neg), nR, nC.neg)
  sd_BRE.pos = matrix(rep(BRE,nC.pos), nR, nC.pos)

  BCE.neg = rexp(nC.neg,1/var.tauCE.neg)
  sd_BCE.neg = matrix(rep(BCE.neg,nR), nR, nC.neg, byrow= TRUE)
  sd_BRCE.neg = sd_BCE.neg + sd_BRE.neg
  BRCE.neg = apply(sd_BRCE.neg, c(1,2), rnorm, n= 1, mean= 0)

  BCE.pos = rexp(nC.pos,1/var.tauCE.pos)
  sd_BCE.pos = matrix(rep(BCE.pos,nR), nR, nC.pos, byrow= TRUE)
  sd_BRCE.pos = sd_BCE.pos + sd_BRE.pos
  BRCE.pos = apply(sd_BRCE.pos, c(1,2), rnorm, n= 1, mean= 0)

  # Aggregate ----

  modA.neg = mu.neg.mat + RC.neg + ARC.neg + RCE.neg + ARCE.neg
  modA.pos = mu.pos.mat + RC.pos + ARC.pos + RCE.pos + ARCE.pos

  modB.neg = mu.neg.mat + RC.neg + BRC.neg + RCE.neg + BRCE.neg
  modB.pos = mu.pos.mat + RC.pos + BRC.pos + RCE.pos + BRCE.pos
  # Z = mu_k + RC + newCrosRC + RCE_Z + newCrosRCE_Z
  # my_list = list(ref=t(ref), new=t(new))

  # Five column format ----

  df = as.data.frame(matrix(0,nrow=nR*(nC.neg+nC.pos)*2,ncol=5))
  colnames(df) = c("caseID","readerID","modalityID","score","truth")
  df$score = c(as.vector(t(modA.neg)),as.vector(t(modB.neg)),
               as.vector(t(modA.pos)),as.vector(t(modB.pos)))
  df$caseID = c(paste("negCase",rep(1:nC.neg,nR*2),sep=""),
                paste("posCase",rep(1:nC.pos,nR*2),sep=""))
  df$readerID = as.factor(paste("reader",c(rep(rep(1:nR,each=nC.neg),2),
                                           rep(rep(1:nR,each=nC.pos),2)),sep=""))
  df$modalityID = as.factor(c(rep(c("testA","testB"),each=nR*nC.neg),
                              rep(c("testA","testB"),each=nR*nC.pos)))
  df$truth = c(rep(0,nC.neg*nR*2),rep(1,nC.pos*nR*2))

  return(df)
}




