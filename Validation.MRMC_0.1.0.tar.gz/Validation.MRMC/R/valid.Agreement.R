#' Validation for Agreement Simulation Model
#'
#' @param VarRC VARiability for Reader and Case. Options are "LL", "HL", "LH", "HH"
#' @param streamID The random number stream used to do the simulation
#' @param pathToResults The place to save the MRMC analysis results
#' @param nTrialsPerStream The number of simulation trials per random number stream
#'
#' @return MRMC analysis results for all simulation trials for this stream. Results are aggregated over trials, but for only the specified streamID. This function is for use in the cluster. This function is a condensed vertion of local steps 3-6 for the Agreement model.
#' @export
#'
#' @examples
#' valid.Agreement('LL',1,2,tempdir())
valid.Agreement = function(VarRC, streamID, nTrialsPerStream, pathToResults){

  # Libraries ----
  library(iMRMC)
  library(parallel)
  library(Validation.MRMC)

  # RNG ----
  set.seed(1)
  RNGkind("L'Ecuyer-CMRG")
  s = .Random.seed
  for (stream in 1:streamID){
    s = nextRNGStream(s)
  }
  .Random.seed <<- s

  # Config ----
  createConfigTable(setting = "default")
  configTable = read.csv(file.path(tempdir(),"configTable.csv"))
  config = as.list(configTable[which(configTable$VarRC == VarRC),])
  configs.Agreement = rep(list(config),nTrialsPerStream)

  # Simulation ----
  dFrame.Agreement = lapply(configs.Agreement, FUN = sim.Agreement)
  dFrame.Agreement = lapply(dFrame.Agreement, FUN = createIMRMCdf, truePositiveFactor = "1")
  Results.Agreement = lapply(dFrame.Agreement, FUN = doIMRMC)

  # Aggregate
  aggregateOverTrials.Agreement = aggregateOverTrials(Results.Agreement)

  # Return ----
  if (pathToResults == "return"){
    return(aggregateOverTrials.Agreement)
  } else {
    save(aggregateOverTrials.Agreement, file=paste(pathToResults,"/valid.Agreement.", VarRC, streamID, ".rda", sep=""))
  }
}
