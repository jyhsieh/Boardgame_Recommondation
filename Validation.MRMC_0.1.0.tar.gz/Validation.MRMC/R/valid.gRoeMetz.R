#' Validation for Generalize Roe & Metz Simulation Model
#'
#' @param VarRC VARiability for Reader and Case. Options are "LL", "HL", "LH", "HH"
#' @param streamID The random number stream used to do the simulation
#' @param pathToResults The place to save the MRMC analysis results
#' @param nTrialsPerStream The number of simulation trials per random number stream
#'
#' @return MRMC analysis results for all simulation trials for this stream. Results are aggregated over trials, but for only the specified streamID. This function is for use in the cluster. This function is a condensed vertion of local steps 3-6 for the gRoeMetz model.
#' @export
#'
#'
#' @examples
#' valid.gRoeMetz('LL',1,2,tempdir())
valid.gRoeMetz = function(VarRC, streamID, nTrialsPerStream, pathToResults){

  # Libraries ----
  library(iMRMC)
  library(parallel)
  library(Validation.MRMC)

  # RNG ----
  set.seed(1)
  RNGkind("L'Ecuyer-CMRG")
  s = .Random.seed
  for (stream in 1:streamID){
    s = nextRNGStream(s)
  }
  .Random.seed <<- s

  # Config ----
  createConfigTable(setting = "default")
  configTable = read.csv(file.path(tempdir(),"configTable.csv"))
  config = as.list(configTable[which(configTable$VarRC == VarRC),])
  config.gRoeMetz = sim.gRoeMetz.config(config$nR, config$nC.neg, config$nC.pos,
                                        config$mu.neg, config$mu.pos, config$var_r,
                                        config$var_c, config$var_rc)

  configs.gRoeMetz = rep(list(config.gRoeMetz),nTrialsPerStream)

  # Simulation ----
  dFrame.gRoeMetz = lapply(configs.gRoeMetz, FUN = sim.gRoeMetz)
  Resutls.gRoeMetz = lapply(dFrame.gRoeMetz, FUN = doIMRMC)

  # Aggregate
  aggregateOverTrials.gRoeMetz = aggregateOverTrials(Resutls.gRoeMetz)

  # Return
  if (pathToResults == "return"){
    return(aggregateOverTrials.gRoeMetz)
  } else {
    save(aggregateOverTrials.gRoeMetz, file=paste(pathToResults,"/valid.gRoeMetz.", VarRC, streamID, ".rda", sep=""))
  }
}
