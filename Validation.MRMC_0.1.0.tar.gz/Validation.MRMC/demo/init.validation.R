
# Library ----
library(ggplot2)
library(parallel)
library(iMRMC)
library(plyr)
library(Validation.MRMC)

# Initialize
VarRC = readline(prompt="Set the levels of VARiability of Reader and variability of Case. Please enter 'LL', 'HL', 'LH' or 'HH': ")
nStreams = readline(prompt="How many random number streams you'd like to use? Please enter an integer: ")
trials = readline(prompt="How many trials per streams? Please enter an integer: ")
mod = readline(prompt="Which model you'd like to validate? Please enter Agreement or gRoeMetz or BOTH: ")
destination = tempdir()
fileName_Batch = "validation"

# Create a batch file
createBatFile(mod, VarRC, nStreams, trials, destination, fileName_Batch)

# Execute bat ----
file = paste(destination,"/", fileName_Batch, sep="")
executeBatFile(file)

# Aggregate ----
results = aggregateOverStreams(mod, VarRC, nStreams, destination)
# save(results,file= paste(destination,"/",mod,".",VarRC,".rda",sep=""))
# load(paste(destination,"/",mod,".",VarRC,".rda",sep=""))

# Validate rejection rate
hlines = ddply(results$agg.AUC,~sim.mod,summarize,mean=mean(reject),expect=0.05)
ggplot(results$agg.AUC,aes(x=Trials, y=reject)) +
  geom_point(size=3,shape=1) +
  facet_grid(~sim.mod) +
  geom_hline(data = hlines, aes(yintercept = expect, linetype="0.05"),colour="red",size=1) +
  geom_hline(data = hlines, aes(yintercept = mean, linetype="MCmean"),colour="blue",size=1) +
  scale_linetype_manual(name ="MC statistics", values = c(2,2),
                        guide = guide_legend(override.aes = list(color=c("red","blue"))))
readline(prompt="Plot for Validation of Rejection Rates. Press enter to continue. ")

# Validate variance estimate
hlines = ddply(results$agg.AUC,~sim.mod,summarize,mean=mean(varAUC),var=var(AUC))
ggplot(results$agg.AUC,aes(x=Trials, y=varAUC)) +
  geom_point(size=3,shape=1) +
  facet_grid(~sim.mod) +
  geom_hline(data = hlines, aes(yintercept = var, linetype="MCvar"),colour="red",size=1) +
  geom_hline(data = hlines, aes(yintercept = mean, linetype="MCmean"),colour="blue",size=1) +
  scale_linetype_manual(name ="MC statistics", values = c(2,2),
                        guide = guide_legend(override.aes = list(color=c("red","blue"))))
readline(prompt="Plot for Validation of Variance Estimate for AUC. Press enter to continue. ")

# Validate variance components: BCK
BCK.reshape = reshape2::melt(results$agg.BCK, measure=1:7)
ggplot(BCK.reshape,aes(x=Trials,y=value,color=sim.mod)) +
  geom_point(size=3,shape=1) +
  facet_wrap(~variable)
readline(prompt="Plot for Validation of Variance Components for AUC. Press enter to continue. ")

# Validate coefficient of variation
temp = plyr::ddply(results$agg.AUC, .(sim.mod), summarize,  xbar = mean(varAUC), std = sd(varAUC))
temp$cv = temp$std/temp$xbar
ggplot(temp, aes(x=factor(sim.mod),y=cv)) + geom_point(size=3,shape=1) + theme_bw()
readline(prompt="Plot for Validation of Coefficient of Variation for Variance of AUC. Press enter to continue. ")


