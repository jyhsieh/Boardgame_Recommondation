## ----global_options, include=FALSE---------------------------------------
knitr::opts_chunk$set(fig.pos = 'H')

## ----steps skipped added, echo=FALSE, fig.cap="Big picture of parallel computing", out.width = '50%',fig.align="center"----
knitr::include_graphics("/Users/JerryHsieh/Desktop/tt.png")

## ------------------------------------------------------------------------
library(parallel)
library(iMRMC)
library(plyr)
library(ggplot2)
library(BlandAltmanLeh)
library(Validation.MRMC)

## ------------------------------------------------------------------------
nTrialsPerStream = 5

## ------------------------------------------------------------------------
nStreams = 2

## ------------------------------------------------------------------------
pathToResults = tempdir()

## ------------------------------------------------------------------------
mod = "BOTH"

## ------------------------------------------------------------------------
VarRC = "LL"

## ------------------------------------------------------------------------
fileName_Batch = "validation"
createBatFile(mod, VarRC, nStreams, nTrialsPerStream, pathToResults, fileName_Batch)

## ------------------------------------------------------------------------
file = paste(pathToResults,"/", fileName_Batch, sep="")
executeBatFile(file)

## ------------------------------------------------------------------------
results = aggregateOverStreams(mod, VarRC, nStreams, pathToResults)

## ------------------------------------------------------------------------
hlines = ddply(results$agg.AUC,~sim.mod,summarize,
               mean=mean(varAUC,na.rm=TRUE),var=var(AUC))
ggplot(results$agg.AUC,aes(x=Trials, y=varAUC)) +
  geom_point(size=3,shape=1) +
  facet_grid(~sim.mod) + 
  geom_hline(data = hlines, aes(yintercept = var,linetype="MCvarAUC"),
             colour="red",size=1) + 
  geom_hline(data = hlines, aes(yintercept = mean,linetype="MCmeanVarAUC"),
             colour="blue",size=1) +
  scale_linetype_manual(name ="MC statistics", values = c(2,2),
                        guide = guide_legend(override.aes = list(color=c("blue","red")))) +
  scale_x_continuous(breaks = pretty(results$agg.AUC$Trials, n = 10)) +
  labs(y="Variance for AUC")

## ------------------------------------------------------------------------
hlines = ddply(results$agg.AUC,~sim.mod,summarize,
               mean=mean(reject,na.rm=TRUE),expect=0.05)
ggplot(results$agg.AUC,aes(x=Trials, y=reject)) +
  geom_point(size=3,shape=1) +
  facet_grid(~sim.mod) + 
  geom_hline(data = hlines, aes(yintercept = expect, linetype="0.05"),
             colour="red",size=1) + 
  geom_hline(data = hlines, aes(yintercept = mean, linetype="MCmeanReject"),
             colour="blue",size=1) +
  scale_linetype_manual(name ="MC statistics", values = c(2,2),
                        guide = guide_legend(override.aes = list(color=c("red","blue")))) +
  scale_x_continuous(breaks = pretty(results$agg.AUC$Trials, n = 10)) + 
  labs(y="Reject=1, Accept=0")

## ------------------------------------------------------------------------
ggplot(results$agg.ROC,aes(x=FPF,y=TPF,color=sim.mod)) + 
  geom_point(size=0.5) +
  facet_wrap(~ Trial) + 
  labs(x="False Positive Fraction",y="True Positive Fraction") +
  guides(color=guide_legend(title="Simulation Model")) +
  scale_x_continuous(breaks = pretty(results$agg.ROC$FPF, n = 4)) 

## ------------------------------------------------------------------------
df_BAplot = merge(subset(results$agg.AUC,sim.mod=="Agreement"),
                  subset(results$agg.AUC,sim.mod=="gRoeMetz"), by="Trials")
bland.altman.plot(df_BAplot$AUCA.x, df_BAplot$AUCA.y, graph.sys = "ggplot2") +
  geom_text(aes(label=df_BAplot$Trial.x),hjust=0, vjust=0) +
  labs(x="Means of modality-A AUCs for two simulation models", 
       y="Differences") +
  ggtitle("Bland Altman Plot for Modality-A AUC") +
  theme_bw()
bland.altman.plot(df_BAplot$AUCB.x, df_BAplot$AUCB.y, graph.sys = "ggplot2") +
  geom_text(aes(label=df_BAplot$Trial.x),hjust=0, vjust=0) +
  labs(x="Means of modality-B AUCs for two simulation models", 
       y="Differences") +
  ggtitle("Bland Altman Plot for Modality-B AUC") +
  theme_bw()

## ------------------------------------------------------------------------
BCK.reshape = reshape2::melt(results$agg.BCK, measure=1:7)
ggplot(BCK.reshape,aes(x=Trials,y=value,color=sim.mod)) +
  geom_point(size=3,shape=1) +
  guides(color=guide_legend(title="Simulation Model")) +
  facet_wrap(~variable) +
  labs(y="Value")

## ------------------------------------------------------------------------
temp = ddply(results$agg.AUC,.(sim.mod), summarize, 
             xbar=mean(varAUC,na.rm=TRUE), std=sd(varAUC))
temp$CV.varAUC = temp$std/temp$xbar
ggplot(temp, aes(x=factor(sim.mod),y=CV.varAUC)) + 
  geom_point(size=3,shape=1) + 
  labs(x="Simulation Model") + 
  theme_bw()

