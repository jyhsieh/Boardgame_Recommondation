## ------------------------------------------------------------------------
library(parallel)
library(iMRMC)
library(plyr)
library(ggplot2)
library(BlandAltmanLeh)
library(Validation.MRMC)

## ------------------------------------------------------------------------
nTrialsPerStream = 5

## ------------------------------------------------------------------------
set.seed(1)
streamID = 100
RNGkind("L'Ecuyer-CMRG")
s = .Random.seed
for (stream in 1:streamID){
  s = nextRNGStream(s)
}
.Random.seed <<- s

## ------------------------------------------------------------------------
pathToResults = tempdir()

## ------------------------------------------------------------------------
createConfigTable(setting = "default")
configTable = read.csv(file.path(tempdir(),"configTable.csv"))

## ----echo=FALSE, results='asis'------------------------------------------
library(knitr)
kable(configTable)

## ------------------------------------------------------------------------
VarRC = "LL"
config = as.list(configTable[which(configTable$VarRC == VarRC),])

## ------------------------------------------------------------------------
config.Agreement = config
config.gRoeMetz = sim.gRoeMetz.config(config$nR, config$nC.neg, config$nC.pos,
                                      config$mu.neg, config$mu.pos, config$var_r,
                                      config$var_c, config$var_rc)

## ------------------------------------------------------------------------
configs.Agreement = rep(list(config.Agreement),nTrialsPerStream)
configs.gRoeMetz = rep(list(config.gRoeMetz),nTrialsPerStream)

## ------------------------------------------------------------------------
dFrames.Agreement = lapply(configs.Agreement, FUN = sim.Agreement)
dFrames.gRoeMetz = lapply(configs.gRoeMetz, FUN = sim.gRoeMetz)

## ------------------------------------------------------------------------
# Reshape the data frames for ggplot2
Trial = rep(paste("Trial",formatC(1:nTrialsPerStream,width=3,flag=0)), each=nrow(dFrames.Agreement[[1]]))
dFrame.Agreement = cbind(ldply(dFrames.Agreement),Trial)
dFrame.gRoeMetz = cbind(ldply(dFrames.gRoeMetz, undoIMRMCdf),Trial)
dFrame = rbind(dFrame.Agreement,dFrame.gRoeMetz)
dFrame$sim.mod = rep(c("Agreement","gRoeMetz"),each=nrow(dFrame.Agreement))

# Plot densities
ggplot(subset(dFrame,Trial=="Trial 001"|Trial=="Trial 002"|Trial=="Trial 003"), aes(x=score,color=factor(truth))) + 
  geom_density(position = "identity",alpha = 0.2) + 
  scale_x_continuous(breaks = pretty(dFrame$score, n = 10)) + 
  facet_grid(Trial ~ sim.mod) +
  labs(x="MRMC Reading Score", y="Density")

## ------------------------------------------------------------------------
dFrames.Agreement = lapply(dFrames.Agreement, FUN = createIMRMCdf, truePositiveFactor = "1")
Results.Agreement = lapply(dFrames.Agreement, FUN = doIMRMC)
Results.gRoeMetz = lapply(dFrames.gRoeMetz, FUN = doIMRMC)

## ------------------------------------------------------------------------
aggregateOverTrials.Agreement = aggregateOverTrials(Results.Agreement)
aggregateOverTrials.gRoeMetz = aggregateOverTrials(Results.gRoeMetz)

## ------------------------------------------------------------------------
save(aggregateOverTrials.Agreement, 
     file = paste(pathToResults,"/valid.Agreement.", VarRC, streamID, ".rda", sep=""))
save(aggregateOverTrials.gRoeMetz, 
     file = paste(pathToResults,"/valid.gRoeMetz.", VarRC, streamID, ".rda", sep=""))

## ------------------------------------------------------------------------
load(paste(pathToResults,"/valid.Agreement.", VarRC, streamID, ".rda", sep=""))
load(paste(pathToResults,"/valid.gRoeMetz.", VarRC, streamID, ".rda", sep=""))

## ------------------------------------------------------------------------
AUC.data.frame = rbind(aggregateOverTrials.Agreement$mc.AUCs,
                       aggregateOverTrials.gRoeMetz$mc.AUCs)
AUC.data.frame$sim.mod = rep(c("Agreement","gRoeMetz"),each=nrow(AUC.data.frame)/2)
hlines = ddply(AUC.data.frame,~sim.mod,summarize,
               mean=mean(varAUC,na.rm=TRUE),var=var(AUC))
ggplot(AUC.data.frame,aes(x=Trial, y=varAUC)) +
  geom_point(size=3,shape=1) +
  facet_grid(~sim.mod) + 
  geom_hline(data = hlines, aes(yintercept = var,linetype="MCvarAUC"),
             colour="red",size=1) + 
  geom_hline(data = hlines, aes(yintercept = mean,linetype="MCmeanVarAUC"),
             colour="blue",size=1) +
  scale_linetype_manual(name ="MC statistics", values = c(2,2),
                        guide = guide_legend(override.aes = list(color=c("blue","red")))) +
  scale_x_continuous(breaks = pretty(AUC.data.frame$Trial, n = 10)) +
  labs(y="Variance for AUC")

## ------------------------------------------------------------------------
hlines = ddply(AUC.data.frame,~sim.mod,summarize,
               mean=mean(reject,na.rm=TRUE),
               expect=0.05)
ggplot(AUC.data.frame,aes(x=Trial, y=reject)) +
  geom_point(size=3,shape=1) +
  facet_grid(~sim.mod) + 
  geom_hline(data = hlines, aes(yintercept = expect, linetype="0.05"),
             colour="red",size=1) + 
  geom_hline(data = hlines, aes(yintercept = mean, linetype="MCmeanReject"),
             colour="blue",size=1) +
  scale_linetype_manual(name ="MC statistics", values = c(2,2),
                        guide = guide_legend(override.aes = list(color=c("red","blue")))) +
  scale_x_continuous(breaks = pretty(AUC.data.frame$Trial, n = 10)) + 
  labs(y="Reject=1, Accept=0")

## ------------------------------------------------------------------------
ROC.data.frame = rbind(aggregateOverTrials.Agreement$mc.ROCs,
                       aggregateOverTrials.gRoeMetz$mc.ROCs)
ROC.data.frame$sim.mod = rep(c("Agreement","gRoeMetz"),each=nrow(ROC.data.frame)/2)
ggplot(ROC.data.frame,aes(x=FPF,y=TPF,color=sim.mod)) + 
  geom_point(size=0.5) +
  facet_wrap(~ Trials) + 
  labs(x="False Positive Fraction",y="True Positive Fraction") +
  guides(color=guide_legend(title="Simulation Model")) +
  scale_x_continuous(breaks = pretty(ROC.data.frame$FPF, n = 4)) 

## ------------------------------------------------------------------------
df_BAplot = merge(aggregateOverTrials.Agreement$mc.AUCs,aggregateOverTrials.gRoeMetz$mc.AUCs,
           by="Trial")
bland.altman.plot(df_BAplot$AUCA.x, df_BAplot$AUCA.y, graph.sys = "ggplot2") +
  geom_text(aes(label=df_BAplot$Trials.x),hjust=0, vjust=0) +
  labs(x="Means of modality-A AUCs for two simulation models", 
       y="Differences") +
  ggtitle("Bland Altman Plot for Modality-A AUC") +
  theme_bw()
bland.altman.plot(df_BAplot$AUCB.x, df_BAplot$AUCB.y, graph.sys = "ggplot2") +
  geom_text(aes(label=df_BAplot$Trials.x),hjust=0, vjust=0) +
  labs(x="Means of modality-B AUCs for two simulation models", 
       y="Differences") +
  ggtitle("Bland Altman Plot for Modality-B AUC") +
  theme_bw()

## ------------------------------------------------------------------------
BCK.data.frame = rbind(aggregateOverTrials.Agreement$mc.BCK,
                       aggregateOverTrials.gRoeMetz$mc.BCK)
BCK.data.frame$sim.mod = rep(c("Agreement","gRoeMetz"),each=nrow(BCK.data.frame)/2)
BCK.reshape = reshape2::melt(BCK.data.frame, measure=1:7)
ggplot(BCK.reshape,aes(x=Trial,y=value,color=sim.mod)) +
  geom_point(size=3,shape=1) +
  facet_wrap(~variable) +
  guides(color=guide_legend(title="Simulation Model")) +
  scale_x_continuous(breaks = pretty(BCK.data.frame$Trial, n = 10)) +
  labs(y="Value")

## ------------------------------------------------------------------------
temp = ddply(AUC.data.frame, .(sim.mod), summarize, 
             xbar=mean(varAUC,na.rm=TRUE), std=sd(varAUC))
temp$CV.varAUC = temp$std/temp$xbar
ggplot(temp, aes(x=factor(sim.mod),y=CV.varAUC)) + 
  geom_point(size=3,shape=1) + theme_bw() +
  labs(x="Simulation Model")

